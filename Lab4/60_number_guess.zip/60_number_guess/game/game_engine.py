import random
import pygame
from game.text_box import TextBox

class GameEngine:
    MAX_ATTEMPTS = 10

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.secret_number = random.randint(1, 100)
        self.attempts = 0
        self.feedback_msg = "Enter a number between 1 and 100"
        self.feedback_color = (220, 220, 220)
        self.game_won = False
        self.game_over = False
        self.range_min = 1
        self.range_max = 100
        self.guess_history = []

        self.input_box = TextBox(width // 2 - 110, 150, 120, 48)
        self.submit_btn = pygame.Rect(width // 2 + 25, 150, 100, 48)

        self.font_title = pygame.font.SysFont(None, 42)
        self.font_medium = pygame.font.SysFont(None, 28)
        self.font_btn = pygame.font.SysFont(None, 26)

    def submit_guess(self):
        if self.game_won or self.game_over:
            return

        if not self.input_box.text:
            self.feedback_msg = "Please enter a number!"
            self.feedback_color = (240, 200, 80)
            return

        guess = int(self.input_box.text)

        if guess < 1 or guess > 100:
            self.feedback_msg = "Please enter a number between 1 and 100!"
            self.feedback_color = (240, 200, 80)
            self.input_box.clear()
            return

        self.attempts += 1
        self.input_box.clear()

        if guess < self.secret_number:
            self.range_min = max(self.range_min, guess + 1)
            self.feedback_msg = f"TOO LOW! (Guess was {guess})"
            self.feedback_color = (80, 160, 240)
            self.guess_history.append((guess, "TOO LOW", self.feedback_color))
        elif guess > self.secret_number:
            self.range_max = min(self.range_max, guess - 1)
            self.feedback_msg = f"TOO HIGH! (Guess was {guess})"
            self.feedback_color = (240, 100, 80)
            self.guess_history.append((guess, "TOO HIGH", self.feedback_color))
        else:
            self.feedback_msg = f"CORRECT! Found in {self.attempts} attempts."
            self.feedback_color = (80, 220, 90)
            self.guess_history.append((guess, "CORRECT", self.feedback_color))
            self.game_won = True

        self.guess_history = self.guess_history[-5:]

        if not self.game_won and self.attempts >= self.MAX_ATTEMPTS:
            self.feedback_msg = f"GAME OVER! The number was {self.secret_number}."
            self.feedback_color = (240, 100, 80)
            self.game_over = True

    def reset(self):
        self.secret_number = random.randint(1, 100)
        self.attempts = 0
        self.feedback_msg = "Enter a number between 1 and 100"
        self.feedback_color = (220, 220, 220)
        self.game_won = False
        self.game_over = False
        self.range_min = 1
        self.range_max = 100
        self.guess_history.clear()
        self.input_box.clear()

    def handle_event(self, event):
        if self.game_won or self.game_over:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                self.reset()
            return

        self.input_box.handle_event(event)

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                self.submit_guess()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.submit_btn.collidepoint(event.pos):
                self.submit_guess()

    def update(self):
        pass

    def render(self, screen):
        screen.fill((30, 34, 42))

        title_surf = self.font_title.render("Number Guessing Arena", True, (245, 245, 245))
        screen.blit(title_surf, (self.width // 2 - title_surf.get_width() // 2, 35))

        attempts_surf = self.font_medium.render(f"Attempts: {self.attempts} / {self.MAX_ATTEMPTS}", True, (180, 185, 195))
        screen.blit(attempts_surf, (self.width // 2 - attempts_surf.get_width() // 2, 95))

        range_surf = self.font_medium.render(f"Valid range: {self.range_min} - {self.range_max}", True, (180, 185, 195))
        screen.blit(range_surf, (self.width // 2 - range_surf.get_width() // 2, 120))

        self.input_box.render(screen)

        pygame.draw.rect(screen, (50, 150, 80), self.submit_btn, border_radius=6)
        pygame.draw.rect(screen, (220, 220, 220), self.submit_btn, width=2, border_radius=6)
        btn_text = self.font_btn.render("SUBMIT", True, (255, 255, 255))
        screen.blit(
            btn_text,
            (self.submit_btn.centerx - btn_text.get_width() // 2, self.submit_btn.centery - btn_text.get_height() // 2),
        )

        feedback_surf = self.font_medium.render(self.feedback_msg, True, self.feedback_color)
        screen.blit(feedback_surf, (self.width // 2 - feedback_surf.get_width() // 2, 235))

        history_title = self.font_medium.render("Recent Guesses", True, (220, 220, 220))
        screen.blit(history_title, (self.width // 2 - history_title.get_width() // 2, 275))

        history_y = 310
        for guess, result, color in reversed(self.guess_history):
            history_surf = self.font_medium.render(f"{guess}: {result}", True, color)
            screen.blit(history_surf, (self.width // 2 - history_surf.get_width() // 2, history_y))
            history_y += 32

        if self.game_won:
            restart_surf = self.font_medium.render("Press [R] to Start a New Game", True, (255, 220, 80))
            screen.blit(restart_surf, (self.width // 2 - restart_surf.get_width() // 2, 500))
        elif self.game_over:
            game_over_surf = self.font_medium.render(f"GAME OVER! The number was {self.secret_number}.", True, (240, 100, 80))
            screen.blit(game_over_surf, (self.width // 2 - game_over_surf.get_width() // 2, 500))
            restart_surf = self.font_medium.render("Press [R] to Start a New Game", True, (255, 220, 80))
            screen.blit(restart_surf, (self.width // 2 - restart_surf.get_width() // 2, 530))
